# kafka-connect-replicator
Kafka Connect connector for replicating topics between Kafka clusters
