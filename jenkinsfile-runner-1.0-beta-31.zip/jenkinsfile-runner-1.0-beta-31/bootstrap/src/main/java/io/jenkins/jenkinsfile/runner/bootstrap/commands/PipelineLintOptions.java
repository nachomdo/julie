package io.jenkins.jenkinsfile.runner.bootstrap.commands;

/**
 * Contains options for linting a Jenkinsfile.
 */
public class PipelineLintOptions extends PipelineOptions {
    // No extra options...yet.
}
