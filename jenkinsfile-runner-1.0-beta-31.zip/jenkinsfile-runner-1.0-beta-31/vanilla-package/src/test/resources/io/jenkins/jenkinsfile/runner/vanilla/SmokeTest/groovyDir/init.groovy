package io.jenkins.jenkinsfile.runner.vanilla.SmokeTest.groovyDir

import hudson.plugins.git.GitSCM
GitSCM.ALLOW_LOCAL_CHECKOUT = true
