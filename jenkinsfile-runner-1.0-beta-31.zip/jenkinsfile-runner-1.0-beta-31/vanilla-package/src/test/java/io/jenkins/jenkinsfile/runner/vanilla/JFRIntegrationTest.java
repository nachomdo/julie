package io.jenkins.jenkinsfile.runner.vanilla;

/**
 * Marker for Jenkinsfile Runner Integration Tests that are quite slow
 * @author Oleg Nenashev
 * @since TODO
 */
public interface JFRIntegrationTest {
}
