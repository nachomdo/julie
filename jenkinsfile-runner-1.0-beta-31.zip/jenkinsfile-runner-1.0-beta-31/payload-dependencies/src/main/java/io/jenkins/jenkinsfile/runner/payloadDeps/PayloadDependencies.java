package io.jenkins.jenkinsfile.runner.payloadDeps;

import org.kohsuke.accmod.Restricted;
import org.kohsuke.accmod.restrictions.NoExternalUse;

@Restricted(NoExternalUse.class)
public class PayloadDependencies {

    // Placeholder class

}
